class TipsModel {
  final String id;
  final String text;
  final String imgPath;
  final String type;
  TipsModel({required this.id, required this.text, required this.imgPath, required this.type});
}
