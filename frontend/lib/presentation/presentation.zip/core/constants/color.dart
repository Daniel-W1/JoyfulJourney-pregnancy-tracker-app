import '../utils/hex_color.dart';

final kPrimaryColor = HexColor("#BC6B6B");
